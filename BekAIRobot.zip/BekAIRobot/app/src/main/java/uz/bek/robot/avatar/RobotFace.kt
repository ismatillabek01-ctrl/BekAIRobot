package uz.bek.robot.avatar

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlinx.coroutines.delay
import uz.bek.robot.ui.Blue
import uz.bek.robot.ui.Neon
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

enum class Mood {
    NEUTRAL, HAPPY, SURPRISED, SERIOUS, SAD;

    companion object {
        fun from(s: String): Mood = when (s.trim().lowercase()) {
            "happy" -> HAPPY
            "surprised" -> SURPRISED
            "serious" -> SERIOUS
            "sad" -> SAD
            else -> NEUTRAL
        }
    }
}

enum class RobotState { IDLE, LISTENING, THINKING, SPEAKING }

/** BEK robotining jonli yuzi: ko'z pirpirashi, lab harakati, bosh qimirlashi, kayfiyatlar. */
@Composable
fun RobotFace(mood: Mood, state: RobotState, mouthLevel: Float, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "bek")
    val phase by inf.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "phase"
    )
    val pulse by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    val blink = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(2200, 5200))
            blink.animateTo(0.06f, tween(70))
            blink.animateTo(1f, tween(110))
        }
    }
    val mouth by animateFloatAsState(mouthLevel, tween(60), label = "mouth")
    val tilt by animateFloatAsState(
        when (state) {
            RobotState.LISTENING -> 6f
            RobotState.THINKING -> -5f
            else -> 0f
        }, tween(500), label = "tilt"
    )

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val glowA = if (state == RobotState.LISTENING) 0.20f + 0.20f * pulse else 0.14f
        drawCircle(
            Brush.radialGradient(listOf(Neon.copy(alpha = glowA), Color.Transparent), Offset(cx, h * 0.42f), w * 0.62f),
            w * 0.62f, Offset(cx, h * 0.42f)
        )
        drawBody(w, h, cx, pulse)
        val idleSway = sin(phase) * 2.5f
        rotate(tilt + idleSway, Offset(cx, h * 0.62f)) {
            drawHead(w, h, cx, mood, state, mouth, blink.value, phase, pulse)
        }
    }
}

private fun DrawScope.drawBody(w: Float, h: Float, cx: Float, pulse: Float) {
    val top = h * 0.72f
    drawRoundRect(
        Brush.verticalGradient(listOf(Color(0xFFF4F6FA), Color(0xFFAEB8C8)), startY = top, endY = h),
        Offset(cx - w * 0.30f, top), Size(w * 0.60f, h * 0.42f), CornerRadius(w * 0.12f)
    )
    drawRoundRect(
        Color(0xFF0B1020), Offset(cx - w * 0.07f, top + h * 0.035f),
        Size(w * 0.14f, h * 0.11f), CornerRadius(w * 0.03f)
    )
    drawCircle(Neon.copy(alpha = 0.55f + 0.45f * pulse), w * 0.022f, Offset(cx, top + h * 0.09f))
}

private fun DrawScope.drawHead(
    w: Float, h: Float, cx: Float, mood: Mood, state: RobotState,
    mouth: Float, blink: Float, phase: Float, pulse: Float
) {
    val hw = w * 0.64f
    val hh = h * 0.50f
    val left = cx - hw / 2
    val top = h * 0.14f

    // antenna
    drawLine(Color(0xFF9AA6B8), Offset(cx, top), Offset(cx, top - h * 0.05f), w * 0.01f, StrokeCap.Round)
    drawCircle(Neon.copy(alpha = 0.5f + 0.5f * pulse), w * 0.018f, Offset(cx, top - h * 0.055f))

    // ears
    val earW = w * 0.065f
    val earH = hh * 0.34f
    val earY = top + hh * 0.33f
    for (side in listOf(-1, 1)) {
        val ex = if (side < 0) left - earW * 0.6f else left + hw - earW * 0.4f
        drawRoundRect(Color(0xFF111827), Offset(ex, earY), Size(earW, earH), CornerRadius(earW * 0.5f))
        drawRoundRect(
            Neon.copy(alpha = 0.7f), Offset(ex + earW * 0.35f, earY + earH * 0.2f),
            Size(earW * 0.3f, earH * 0.6f), CornerRadius(earW * 0.15f)
        )
    }

    // head shell
    drawRoundRect(
        Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFC9D1DE)), startY = top, endY = top + hh),
        Offset(left, top), Size(hw, hh), CornerRadius(hw * 0.28f)
    )

    // visor
    val vw = hw * 0.86f
    val vh = hh * 0.64f
    val vx = cx - vw / 2
    val vy = top + hh * 0.17f
    drawRoundRect(
        Brush.verticalGradient(listOf(Color(0xFF0A0F1C), Color(0xFF020409)), startY = vy, endY = vy + vh),
        Offset(vx, vy), Size(vw, vh), CornerRadius(vh * 0.38f)
    )
    drawRoundRect(
        Blue.copy(alpha = 0.25f), Offset(vx, vy), Size(vw, vh), CornerRadius(vh * 0.38f),
        style = Stroke(w * 0.004f)
    )

    // eyes
    val ey = vy + vh * 0.42f
    val gaze = if (state == RobotState.THINKING) sin(phase * 2) * vw * 0.03f else 0f
    val ew = vw * 0.16f
    val baseH = vh * 0.34f
    val eh = when (state) {
        RobotState.LISTENING -> baseH * 1.1f
        else -> baseH
    } * blink
    for (side in listOf(-1, 1)) {
        val ex = cx + side * vw * 0.22f + gaze
        drawEye(mood, ex, ey, ew, eh, baseH, side)
    }

    // mouth
    val my = vy + vh * 0.80f
    val mw = vw * 0.11f
    if (state == RobotState.SPEAKING) {
        val mh = mw * (0.18f + 1.0f * mouth)
        drawOval(Neon, Offset(cx - mw, my - mh / 2), Size(mw * 2, mh))
    } else {
        val sw = Stroke(w * 0.012f, cap = StrokeCap.Round)
        when (mood) {
            Mood.HAPPY -> drawArc(Neon, 15f, 150f, false, Offset(cx - mw * 1.3f, my - mw * 0.7f), Size(mw * 2.6f, mw * 1.4f), style = sw)
            Mood.SAD -> drawArc(Neon, 195f, 150f, false, Offset(cx - mw, my - mw * 0.2f), Size(mw * 2f, mw), style = sw)
            Mood.SERIOUS -> drawLine(Neon, Offset(cx - mw, my), Offset(cx + mw, my), w * 0.012f, StrokeCap.Round)
            Mood.SURPRISED -> drawCircle(Neon, mw * 0.5f, Offset(cx, my), style = sw)
            Mood.NEUTRAL -> drawArc(Neon, 25f, 130f, false, Offset(cx - mw, my - mw * 0.5f), Size(mw * 2f, mw), style = sw)
        }
    }
}

private fun DrawScope.drawEye(mood: Mood, ex: Float, ey: Float, ew: Float, eh: Float, baseH: Float, side: Int) {
    val glow = Neon.copy(alpha = 0.22f)
    when (mood) {
        Mood.HAPPY -> {
            val st = Stroke(ew * 0.42f, cap = StrokeCap.Round)
            drawArc(Neon, 180f, 180f, false, Offset(ex - ew * 0.7f, ey - baseH * 0.25f), Size(ew * 1.4f, baseH * 0.7f), style = st)
        }
        Mood.SURPRISED -> {
            drawOval(glow, Offset(ex - ew * 0.75f, ey - eh * 0.7f), Size(ew * 1.5f, eh * 1.4f))
            drawOval(Neon, Offset(ex - ew * 0.6f, ey - eh * 0.58f), Size(ew * 1.2f, eh * 1.16f))
        }
        Mood.SERIOUS -> {
            val hh = eh * 0.5f
            drawRoundRect(Neon, Offset(ex - ew * 0.6f, ey - hh / 2), Size(ew * 1.2f, hh), CornerRadius(hh / 2))
            drawLine(
                Neon, Offset(ex - ew * 0.7f, ey - baseH * 0.55f - side * ew * 0.12f),
                Offset(ex + ew * 0.7f, ey - baseH * 0.55f + side * ew * 0.12f), ew * 0.16f, StrokeCap.Round
            )
        }
        Mood.SAD -> {
            rotate(side * 14f, Offset(ex, ey)) {
                drawOval(glow, Offset(ex - ew * 0.6f, ey - eh * 0.45f), Size(ew * 1.2f, eh * 0.9f))
                drawOval(Neon, Offset(ex - ew * 0.5f, ey - eh * 0.38f), Size(ew, eh * 0.76f))
            }
        }
        Mood.NEUTRAL -> {
            drawOval(glow, Offset(ex - ew * 0.7f, ey - eh * 0.62f), Size(ew * 1.4f, eh * 1.24f))
            drawOval(Neon, Offset(ex - ew * 0.5f, ey - eh * 0.5f), Size(ew, eh))
        }
    }
}
