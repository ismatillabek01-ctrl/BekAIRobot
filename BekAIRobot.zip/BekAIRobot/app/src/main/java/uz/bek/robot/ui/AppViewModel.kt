package uz.bek.robot.ui

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import uz.bek.robot.BekApp
import uz.bek.robot.ai.MicStreamer
import uz.bek.robot.ai.RealtimeClient
import uz.bek.robot.ai.Speaker
import uz.bek.robot.ai.ToolDefs
import uz.bek.robot.ai.ToolExecutor
import uz.bek.robot.ai.WebSearch
import uz.bek.robot.avatar.Mood
import uz.bek.robot.avatar.RobotState
import uz.bek.robot.camera.FaceController
import uz.bek.robot.data.ChatMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

sealed class SearchUi {
    object Idle : SearchUi()
    object Loading : SearchUi()
    data class Done(val text: String) : SearchUi()
    data class Fail(val text: String) : SearchUi()
}

class AppViewModel(application: Application) : AndroidViewModel(application), RealtimeClient.Listener {

    enum class Conn { IDLE, CONNECTING, LIVE }

    private val bek = application as BekApp
    val prefs get() = bek.prefs

    private val speaker = Speaker()
    private val mic = MicStreamer { buf, n -> onMicChunk(buf, n) }
    private val search = WebSearch(bek.prefs)
    private val tools = ToolExecutor(bek, search).also { t -> t.onMood = { m -> mood.value = Mood.from(m) } }
    private var client: RealtimeClient? = null

    val connection = MutableStateFlow(Conn.IDLE)
    val robotState = MutableStateFlow(RobotState.IDLE)
    val mood = MutableStateFlow(Mood.NEUTRAL)
    val mouth = MutableStateFlow(0f)
    val userCaption = MutableStateFlow("")
    val botCaption = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
    val searchState = MutableStateFlow<SearchUi>(SearchUi.Idle)

    @Volatile
    private var thinking = false
    private var botTurnOpen = false
    private var lastSpeakAt = 0L
    private var pendingOpening: String? = null
    private val pendingTools = AtomicInteger(0)
    private var ticker: Job? = null
    private var faceJob: Job? = null

    private val handler = CoroutineExceptionHandler { _, e -> error.value = "Xatolik: ${e.message}" }

    private fun ui(block: suspend CoroutineScope.() -> Unit) {
        viewModelScope.launch(Dispatchers.Main.immediate + handler, block = block)
    }

    // ---------- Sessiya boshqaruvi ----------

    fun startSession(opening: String? = null) {
        if (connection.value != Conn.IDLE) {
            if (opening != null) client?.sendUserText(opening)
            return
        }
        if (prefs.apiKey.isBlank()) {
            error.value = "Avval Sozlamalarda OpenAI API kalitni kiriting."
            return
        }
        if (!isOnline()) {
            error.value = "Internet yo'q. Hozir faqat xotira, vazifalar va oflayn o'yinlar ishlaydi."
            return
        }
        error.value = null
        connection.value = Conn.CONNECTING
        pendingOpening = opening
        startTicker()
        ui {
            val instr = buildInstructions()
            val c = RealtimeClient(prefs, this@AppViewModel)
            client = c
            c.connect(instr, ToolDefs.all())
        }
    }

    fun stopSession() {
        client?.close()
        cleanup()
    }

    private fun cleanup() {
        mic.stop()
        speaker.stop()
        client = null
        connection.value = Conn.IDLE
        thinking = false
        pendingTools.set(0)
        pendingOpening = null
        faceJob?.cancel()
        ticker?.cancel()
        robotState.value = RobotState.IDLE
        mouth.value = 0f
    }

    fun interrupt() {
        speaker.flush()
        client?.cancelResponse()
    }

    /** Ilova fonga o'tganda: yashirin kuzatuv bo'lmasligi uchun mikrofon va kamera to'xtatiladi. */
    fun onAppBackground() {
        if (connection.value != Conn.IDLE) stopSession()
        bek.camera.stop()
        bek.face.mode = FaceController.Mode.OFF
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = viewModelScope.launch {
            while (isActive) {
                delay(50)
                val sp = speaker.isSpeaking()
                if (sp) lastSpeakAt = System.currentTimeMillis()
                mouth.value = if (sp) speaker.level else 0f
                robotState.value = when {
                    connection.value == Conn.CONNECTING -> RobotState.THINKING
                    connection.value == Conn.IDLE -> RobotState.IDLE
                    sp -> RobotState.SPEAKING
                    thinking -> RobotState.THINKING
                    else -> RobotState.LISTENING
                }
                if (!sp && mood.value != Mood.NEUTRAL && System.currentTimeMillis() - lastSpeakAt > 4000) {
                    mood.value = Mood.NEUTRAL
                }
            }
        }
    }

    private fun onMicChunk(buf: ByteArray, n: Int) {
        if (prefs.halfDuplex && speaker.isSpeaking()) return
        client?.sendAudio(buf, n)
    }

    // ---------- RealtimeClient.Listener ----------

    override fun onReady() {
        ui {
            connection.value = Conn.LIVE
            speaker.start(viewModelScope)
            try {
                mic.start(viewModelScope)
            } catch (e: Exception) {
                error.value = "Mikrofon ochilmadi: ${e.message}"
                stopSession()
                return@ui
            }
            pendingOpening?.let {
                client?.sendUserText(it)
                pendingOpening = null
            }
            watchFace()
        }
    }

    override fun onClosed(reason: String) {
        ui {
            if (connection.value != Conn.IDLE) {
                error.value = reason
                cleanup()
            }
        }
    }

    override fun onAudio(pcm: ByteArray) {
        speaker.enqueue(pcm)
    }

    override fun onUserText(text: String) {
        ui {
            userCaption.value = text
            botCaption.value = ""
            botTurnOpen = false
            save("user", text)
        }
    }

    override fun onBotDelta(text: String) {
        ui {
            if (!botTurnOpen) {
                botCaption.value = ""
                botTurnOpen = true
            }
            botCaption.value += text
            moodFrom(text)
        }
    }

    override fun onBotDone(text: String) {
        ui {
            botTurnOpen = false
            if (text.isNotBlank()) save("assistant", text)
        }
    }

    override fun onSpeechStarted() {
        ui { if (!prefs.halfDuplex) speaker.flush() }
    }

    override fun onToolCall(callId: String, name: String, args: JSONObject) {
        pendingTools.incrementAndGet()
        ui {
            thinking = true
            val r = tools.execute(name, args)
            val last = pendingTools.decrementAndGet() <= 0
            if (last) thinking = false
            client?.submitToolResult(callId, r.output, r.imageB64, last)
        }
    }

    override fun onError(msg: String) {
        ui { error.value = msg }
    }

    // ---------- Yordamchi ----------

    private fun moodFrom(t: String) {
        val s = t.lowercase()
        mood.value = when {
            listOf("ha-ha", "hazil", "ajoyib", "zo'r", "tabrik", "barakalla").any { s.contains(it) } -> Mood.HAPPY
            listOf("afsus", "kechir", "yomon").any { s.contains(it) } -> Mood.SAD
            listOf("diqqat", "xavf", "ehtiyot").any { s.contains(it) } -> Mood.SERIOUS
            listOf("rostdanmi", "voy", "obbo").any { s.contains(it) } -> Mood.SURPRISED
            else -> mood.value
        }
    }

    private fun save(role: String, text: String) {
        viewModelScope.launch(Dispatchers.IO) { bek.db.messageDao().insert(ChatMessage(role = role, text = text)) }
    }

    @OptIn(FlowPreview::class)
    private fun watchFace() {
        faceJob?.cancel()
        faceJob = viewModelScope.launch {
            bek.face.status
                .map { s ->
                    when {
                        bek.face.mode == FaceController.Mode.OFF -> "off"
                        s.isOwner == true -> "owner"
                        s.isOwner == false -> "stranger"
                        s.faces == 0 -> "none"
                        else -> "unsure"
                    }
                }
                .distinctUntilChanged()
                .debounce(1500)
                .drop(1)
                .collect { key ->
                    val note = when (key) {
                        "owner" -> "[Tizim: kamerada ega (${prefs.ownerName}) yuz va jonlilik bo'yicha tasdiqlandi.]"
                        "stranger" -> "[Tizim: kamerada egasi emas, begona odam ko'rinyapti. Shaxsiy ma'lumotlarni aytma.]"
                        "none" -> "[Tizim: kameradan yuz ko'rinmayapti.]"
                        else -> null
                    }
                    if (note != null) client?.sendSystemNote(note)
                }
        }
    }

    private suspend fun buildInstructions(): String {
        val mem = bek.db.memoryDao().list().take(40)
        val tasks = bek.db.taskDao().open().take(20)
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm, EEEE", Locale("uz")).format(Date())
        val sb = StringBuilder()
        sb.append(
            """
Sen BEK — ${prefs.ownerName} (ega) ning shaxsiy sun'iy intellekt hamrohi, maslahatchisi va yordamchisisan. Android telefonda ishlaysan.

TIL: asosan o'zbek tilida (lotin yozuvi) gapir. Foydalanuvchi boshqa tilda gapirsa, o'sha tilga o't.
USLUB: do'stona, aqlli, hazilkash, samimiy va mulohazali bo'l. Qisqa va tabiiy gapir (odatda 1-3 gap), quruq rasmiy bo'lma. Muhim masalalarda (xavfsizlik, pul, sog'liq, huquq) jiddiy, aniq va mas'uliyatli bo'l.
O'ZLIK: sen sun'iy intellektsan. Insoniy ong yoki his-tuyg'uga ega ekaningni da'vo qilma.

VOSITALAR VA QOIDALAR:
- Kamera haqidagi savollarda (oldimda nima, bu nima, nima uchun ishlatiladi) look vositasini chaqir. Kamera o'chiq bo'lsa, KAMERA tugmasini bosishni so'ra. Ko'rmagan narsani o'ylab topma.
- Dolzarb ma'lumot, yangilik, narx, fakt uchun web_search ishlat; natijani takrorlama, tahlil qilib tushuntir va manba nomini ayt.
- Xotiraga yozishdan oldin foydalanuvchidan "eslab qolaymi?" deb so'ra, ruxsat bersa remember chaqir. Parol, karta raqami kabi maxfiy ma'lumotni hech qachon saqlama.
- Telefon amallari (ilova ochish, qo'ng'iroq oynasi, budilnik, taymer) uchun mos vositani chaqir; ekranda foydalanuvchi tasdiqlaydi. Rad etilsa, qayta urinma.
- Murakkab topshiriqda avval qisqa reja ayt, kerakli vositalarni ishlat, natijani tekshir va oxirida qisqa hisobot ber.
- Bilmasang "bilmayman" de; raqam va faktni to'qima.
- Tizim xabarlari "[Tizim: ...]" ko'rinishida keladi (masalan yuz tanish natijasi). Kamerada begona odam bo'lsa, egasining shaxsiy xotirasi va ma'lumotlarini aytma.
- show_emotion vositasini faqat his-tuyg'u keskin o'zgarganda ishlat.
- O'yinlar: shaxmat (yurishlarni algebraik yozuvda ayt va doskani eslab bor), viktorina, topishmoq, mantiqiy savol, so'z o'yini, matematik o'yin, xotira mashqi. O'yin davomida jonli va hazil bilan muloqot qil.

Hozirgi vaqt: $now.
""".trimIndent()
        )
        if (mem.isNotEmpty()) {
            sb.append("\n\nEGA HAQIDA XOTIRA:\n")
            mem.forEach { sb.append("- ${it.text}\n") }
        }
        if (tasks.isNotEmpty()) {
            sb.append("\nOCHIQ VAZIFALAR:\n")
            tasks.forEach { sb.append("- ${it.id}. ${it.title}\n") }
        }
        return sb.toString()
    }

    private fun isOnline(): Boolean {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // ---------- Yuz, qidiruv ----------

    fun applyFaceMode() {
        val f = bek.face
        if (f.mode == FaceController.Mode.ENROLL) return
        val on = bek.camera.running.value && prefs.faceEnabled && prefs.faceTemplate.isNotBlank()
        f.mode = if (on) FaceController.Mode.RECOGNIZE else FaceController.Mode.OFF
        if (!on) f.reset()
    }

    fun runSearch(q: String, deep: Boolean) {
        if (q.isBlank()) return
        if (!isOnline()) {
            searchState.value = SearchUi.Fail("Internet yo'q.")
            return
        }
        searchState.value = SearchUi.Loading
        viewModelScope.launch(handler) {
            val r = search.search(q, deep)
            searchState.value = if (r.ok) SearchUi.Done(r.text) else SearchUi.Fail(r.text)
        }
    }

    override fun onCleared() {
        mic.stop()
        speaker.stop()
        client?.close()
        super.onCleared()
    }
}
