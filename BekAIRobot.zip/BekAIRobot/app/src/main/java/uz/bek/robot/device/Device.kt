package uz.bek.robot.device

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withTimeoutOrNull
import uz.bek.robot.R

/** Muhim telefon amallari uchun ekranda foydalanuvchi tasdig'ini so'raydi. */
class ConfirmBus {
    data class Request(val text: String, val result: CompletableDeferred<Boolean>)

    val pending = MutableStateFlow<Request?>(null)

    suspend fun ask(text: String): Boolean {
        val r = Request(text, CompletableDeferred())
        pending.value = r
        val ok = withTimeoutOrNull(30_000) { r.result.await() } ?: false
        pending.value = null
        return ok
    }
}

class DeviceActions(private val ctx: Context, private val confirm: ConfirmBus) {

    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    suspend fun openApp(name: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = name.trim().lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "«$name» nomli ilova topilmadi."
        val label = match.loadLabel(pm).toString()
        if (!confirm.ask("Bek «$label» ilovasini ochmoqchi. Ruxsat berasizmi?")) return "Foydalanuvchi ruxsat bermadi."
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "Ilovani ochib bo'lmadi."
        launch(intent)
        return "«$label» ochildi."
    }

    suspend fun setAlarm(hour: Int, minute: Int, label: String): String {
        val hh = hour.coerceIn(0, 23)
        val mm = minute.coerceIn(0, 59)
        val t = "%02d:%02d".format(hh, mm)
        if (!confirm.ask("Bek $t ga budilnik o'rnatmoqchi. Ruxsat berasizmi?")) return "Foydalanuvchi ruxsat bermadi."
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hh)
            .putExtra(AlarmClock.EXTRA_MINUTES, mm)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        return try {
            launch(i)
            "Budilnik oynasi ochildi ($t). Foydalanuvchi uni tasdiqlaydi."
        } catch (e: Exception) {
            "Budilnik ilovasi topilmadi."
        }
    }

    suspend fun setTimer(seconds: Int, label: String): String {
        val s = seconds.coerceIn(1, 86_400)
        if (!confirm.ask("Bek $s soniyalik taymer o'rnatmoqchi. Ruxsat berasizmi?")) return "Foydalanuvchi ruxsat bermadi."
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, s)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        return try {
            launch(i)
            "Taymer oynasi ochildi."
        } catch (e: Exception) {
            "Taymer ilovasi topilmadi."
        }
    }

    fun findContacts(name: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )?.use { c ->
            while (c.moveToNext() && out.size < 8) out.add((c.getString(0) ?: "") to (c.getString(1) ?: ""))
        }
        return out
    }

    fun contactsText(name: String): String {
        if (!has(Manifest.permission.READ_CONTACTS)) {
            return "Kontaktlarga ruxsat berilmagan. Sozlamalar ekranidan «Kontaktlar» ruxsatini bering."
        }
        val r = findContacts(name)
        return if (r.isEmpty()) "«$name» bo'yicha kontakt topilmadi." else r.joinToString("\n") { "${it.first}: ${it.second}" }
    }

    suspend fun dial(target: String): String {
        val digits = target.filter { it.isDigit() || it == '+' }
        val isNumber = digits.length >= 5 && target.count { it.isLetter() } == 0
        var number = digits
        var who = target
        if (!isNumber) {
            if (!has(Manifest.permission.READ_CONTACTS)) {
                return "Kontaktlarga ruxsat berilmagan. Sozlamalar ekranidan «Kontaktlar» ruxsatini bering."
            }
            val c = findContacts(target).firstOrNull() ?: return "«$target» kontakti topilmadi."
            who = c.first
            number = c.second
        }
        if (!confirm.ask("Bek $who ($number) uchun qo'ng'iroq oynasini ochmoqchi. Ruxsat berasizmi?")) {
            return "Foydalanuvchi ruxsat bermadi."
        }
        launch(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:" + android.net.Uri.encode(number))))
        return "Qo'ng'iroq oynasi ochildi: $who. Qo'ng'iroqni foydalanuvchi o'zi bosadi."
    }

    fun music(action: String): String {
        val code = when (action.lowercase()) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "Noma'lum amal: $action (play, pause, next, previous)"
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Musiqa buyrug'i yuborildi: $action"
    }

    fun findFiles(query: String): String {
        val out = mutableListOf<String>()
        try {
            ctx.contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                arrayOf(MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.SIZE),
                "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?",
                arrayOf("%$query%"),
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 8) {
                    out.add("${c.getString(0)} (${c.getLong(1) / 1024} KB)")
                }
            }
        } catch (e: Exception) {
            return "Fayl qidirishda xato: ${e.message}"
        }
        return if (out.isEmpty()) "«$query» bo'yicha fayl topilmadi (Android faqat ruxsat berilgan media fayllarni ko'rsatadi)."
        else out.joinToString("\n")
    }
}

object Reminders {
    const val CHANNEL = "bek_reminders"

    fun createChannel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Eslatmalar", NotificationManager.IMPORTANCE_HIGH))
    }

    fun schedule(ctx: Context, id: Long, title: String, atMillis: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx, id.toInt(),
            Intent(ctx, ReminderReceiver::class.java).putExtra("title", title).putExtra("id", id.toInt()),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    @SuppressLint("MissingPermission")
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Eslatma"
        val id = intent.getIntExtra("id", 0)
        Reminders.createChannel(context)
        val n = NotificationCompat.Builder(context, Reminders.CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("BEK eslatmasi")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try {
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
        } catch (_: Exception) {
        }
    }
}
