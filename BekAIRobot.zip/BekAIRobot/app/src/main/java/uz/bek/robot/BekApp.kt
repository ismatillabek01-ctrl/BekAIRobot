package uz.bek.robot

import android.app.Application
import uz.bek.robot.camera.CameraHub
import uz.bek.robot.camera.FaceController
import uz.bek.robot.camera.FaceEngine
import uz.bek.robot.data.AppDb
import uz.bek.robot.data.Prefs
import uz.bek.robot.device.ConfirmBus
import uz.bek.robot.device.Reminders

class BekApp : Application() {
    lateinit var prefs: Prefs
    lateinit var db: AppDb
    lateinit var camera: CameraHub
    lateinit var confirm: ConfirmBus
    lateinit var face: FaceController

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        db = AppDb.create(this)
        camera = CameraHub(this)
        confirm = ConfirmBus()
        face = FaceController(FaceEngine(this), prefs)
        camera.frameCallback = { bmp -> face.onFrame(bmp) }
        Reminders.createChannel(this)
    }
}
