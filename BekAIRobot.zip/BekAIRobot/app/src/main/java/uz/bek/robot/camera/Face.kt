package uz.bek.robot.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.SystemClock
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.flow.MutableStateFlow
import org.tensorflow.lite.Interpreter
import uz.bek.robot.data.Prefs
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class FaceObs(val faces: Int, val leftEye: Float?, val rightEye: Float?, val embedding: FloatArray?)

/**
 * ML Kit (yuzni aniqlash + ko'z ochiqligi) va TFLite yuz embedding modeli (assets/mobilefacenet.tflite).
 * Model fayli bo'lmasa ham ilova ishlaydi: faqat odam soni va ko'z pirpirashi aniqlanadi.
 */
class FaceEngine(private val ctx: Context) {
    private val exec = Executors.newSingleThreadExecutor()
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setMinFaceSize(0.2f)
            .build()
    )
    private var interp: Interpreter? = null
    private var inSize = 112
    private var outDim = 192

    init {
        try {
            val bytes = ctx.assets.open(MODEL).use { it.readBytes() }
            val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
            buf.put(bytes)
            buf.rewind()
            val it = Interpreter(buf, Interpreter.Options().setNumThreads(2))
            inSize = it.getInputTensor(0).shape()[1]
            outDim = it.getOutputTensor(0).shape()[1]
            interp = it
        } catch (_: Exception) {
            interp = null
        }
    }

    val modelAvailable: Boolean get() = interp != null

    fun analyze(bmp: Bitmap, wantEmbedding: Boolean, cb: (FaceObs) -> Unit) {
        detector.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener(exec) { faces ->
                val f = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                if (f == null) {
                    cb(FaceObs(0, null, null, null))
                } else {
                    val emb = if (wantEmbedding) embed(bmp, f.boundingBox) else null
                    cb(FaceObs(faces.size, f.leftEyeOpenProbability, f.rightEyeOpenProbability, emb))
                }
            }
            .addOnFailureListener(exec) { cb(FaceObs(0, null, null, null)) }
    }

    private fun embed(bmp: Bitmap, box: Rect): FloatArray? {
        val model = interp ?: return null
        return try {
            val m = (box.width() * 0.15f).toInt()
            val l = max(0, box.left - m)
            val t = max(0, box.top - m)
            val r = min(bmp.width, box.right + m)
            val b = min(bmp.height, box.bottom + m)
            if (r - l < 30 || b - t < 30) return null
            val crop = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
            val s = Bitmap.createScaledBitmap(crop, inSize, inSize, true)
            val input = ByteBuffer.allocateDirect(4 * inSize * inSize * 3).order(ByteOrder.nativeOrder())
            val px = IntArray(inSize * inSize)
            s.getPixels(px, 0, inSize, 0, 0, inSize, inSize)
            for (p in px) {
                input.putFloat((((p shr 16) and 0xFF) - 127.5f) / 128f)
                input.putFloat((((p shr 8) and 0xFF) - 127.5f) / 128f)
                input.putFloat(((p and 0xFF) - 127.5f) / 128f)
            }
            input.rewind()
            val out = Array(1) { FloatArray(outDim) }
            model.run(input, out)
            normalize(out[0])
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        const val MODEL = "mobilefacenet.tflite"

        fun normalize(v: FloatArray): FloatArray {
            var s = 0.0
            for (x in v) s += x.toDouble() * x
            val n = sqrt(s).toFloat().coerceAtLeast(1e-6f)
            return FloatArray(v.size) { v[it] / n }
        }

        fun cosine(a: FloatArray, b: FloatArray): Float {
            if (a.size != b.size) return -1f
            var d = 0f
            for (i in a.indices) d += a[i] * b[i]
            return d
        }
    }
}

/** Yuzni ro'yxatdan o'tkazish, tanish va jonlilik (ko'z pirpirashi) tekshiruvi holat mashinasi. */
class FaceController(private val engine: FaceEngine, private val prefs: Prefs) {
    enum class Mode { OFF, RECOGNIZE, ENROLL }

    data class Status(
        val text: String,
        val isOwner: Boolean?,
        val faces: Int,
        val live: Boolean,
        val progress: Float = 0f
    )

    val status = MutableStateFlow(Status("Yuzni tanish o'chiq", null, 0, false))

    @Volatile
    var mode = Mode.OFF

    val modelAvailable: Boolean get() = engine.modelAvailable

    private val busy = AtomicBoolean(false)
    private var blinkAt = 0L
    private var wasClosed = false
    private val samples = mutableListOf<FloatArray>()
    private var lastSample = 0L

    fun reset() {
        samples.clear()
        blinkAt = 0L
        wasClosed = false
        status.value = Status("Yuzni tanish o'chiq", null, 0, false)
    }

    fun startEnroll() {
        samples.clear()
        blinkAt = 0L
        mode = Mode.ENROLL
        status.value = Status("Kameraga qarang va ko'zingizni pirpiratib oling", null, 0, false)
    }

    fun clearTemplate() {
        prefs.faceTemplate = ""
        mode = Mode.OFF
        reset()
    }

    fun onFrame(bmp: Bitmap) {
        val m = mode
        if (m == Mode.OFF) return
        if (!busy.compareAndSet(false, true)) return
        val needEmb = engine.modelAvailable && (m == Mode.RECOGNIZE || (m == Mode.ENROLL && isLive()))
        try {
            engine.analyze(bmp, needEmb) { obs ->
                try {
                    handle(obs)
                } finally {
                    busy.set(false)
                }
            }
        } catch (_: Exception) {
            busy.set(false)
        }
    }

    private fun isLive() = SystemClock.elapsedRealtime() - blinkAt < 15000 && blinkAt != 0L

    private fun handle(obs: FaceObs) {
        val now = SystemClock.elapsedRealtime()
        if (obs.faces == 0) {
            status.value = Status("Yuz ko'rinmayapti", null, 0, false)
            return
        }
        val le = obs.leftEye
        val re = obs.rightEye
        if (le != null && re != null) {
            val closed = le < 0.3f && re < 0.3f
            val open = le > 0.6f && re > 0.6f
            if (wasClosed && open) blinkAt = now
            if (closed) wasClosed = true else if (open) wasClosed = false
        }
        val live = isLive()
        val count = obs.faces

        if (mode == Mode.ENROLL) {
            if (!engine.modelAvailable) {
                status.value = Status("Yuz modeli yo'q: assets/mobilefacenet.tflite faylini qo'shing", null, count, live)
                return
            }
            if (!live) {
                status.value = Status("Ko'zingizni pirpiratib oling (jonlilik tekshiruvi)", null, count, false)
                return
            }
            val e = obs.embedding
            if (e != null && now - lastSample > 350) {
                lastSample = now
                samples.add(e)
            }
            val p = samples.size / SAMPLES.toFloat()
            if (samples.size >= SAMPLES) {
                val avg = FloatArray(samples[0].size)
                for (s in samples) for (i in avg.indices) avg[i] += s[i]
                val tpl = FaceEngine.normalize(avg)
                prefs.faceTemplate = tpl.joinToString(",")
                samples.clear()
                mode = Mode.RECOGNIZE
                status.value = Status("Yuz ro'yxatdan o'tdi", true, count, true, 1f)
            } else {
                status.value = Status("Yuz yozilmoqda… boshni sekin aylantiring", null, count, true, p)
            }
            return
        }

        // RECOGNIZE
        if (!engine.modelAvailable) {
            status.value = Status("Kadrda $count ta odam (shaxsni tanish uchun model fayli kerak)", null, count, live)
            return
        }
        val tplStr = prefs.faceTemplate
        if (tplStr.isBlank()) {
            status.value = Status("Egasi yuzi ro'yxatdan o'tmagan", null, count, live)
            return
        }
        val e = obs.embedding ?: return
        val tpl = tplStr.split(",").map { it.toFloat() }.toFloatArray()
        val sim = FaceEngine.cosine(e, tpl)
        val pct = (sim * 100).toInt()
        status.value = when {
            sim >= prefs.faceThreshold && live ->
                Status("Ega tanildi: ${prefs.ownerName} (moslik $pct%)", true, count, true)
            sim >= prefs.faceThreshold ->
                Status("Yuz egaga o'xshaydi ($pct%), lekin jonlilik tasdiqlanmadi — ko'zni pirpiratib qo'ying", null, count, false)
            else -> Status("Begona odam ($pct%)", false, count, live)
        }
    }

    companion object {
        const val SAMPLES = 6
    }
}
