package uz.bek.robot.ai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import uz.bek.robot.BekApp
import uz.bek.robot.data.MemoryItem
import uz.bek.robot.data.TaskItem
import uz.bek.robot.device.DeviceActions
import uz.bek.robot.device.Reminders
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ToolResult(val output: String, val imageB64: String? = null)

object ToolDefs {
    private fun p(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)

    private fun fn(
        name: String,
        desc: String,
        props: Map<String, JSONObject> = emptyMap(),
        required: List<String> = emptyList()
    ): JSONObject {
        val pr = JSONObject()
        props.forEach { (k, v) -> pr.put(k, v) }
        return JSONObject().put("type", "function").put("name", name).put("description", desc)
            .put(
                "parameters", JSONObject().put("type", "object").put("properties", pr)
                    .put("required", JSONArray(required))
            )
    }

    fun all(): JSONArray = JSONArray().apply {
        put(fn("look", "Telefon kamerasidan hozirgi kadrni ko'rib, atrofni tahlil qiladi. Foydalanuvchi 'oldimda nima turibdi', 'bu nima' kabi savol bersa chaqir.",
            mapOf("camera" to p("string", "Ixtiyoriy: 'front' (old) yoki 'back' (orqa) kamera")))
        )
        put(fn("switch_camera", "Old va orqa kamerani almashtiradi."))
        put(fn("web_search", "Internetdan dolzarb ma'lumot, yangilik, narx, fakt qidiradi va tahlilli xulosa qaytaradi.",
            mapOf(
                "query" to p("string", "Qidiruv so'rovi (aniq va to'liq)"),
                "deep" to p("boolean", "Chuqur qidiruv: ko'p manbani solishtirish kerak bo'lsa true")
            ), listOf("query")))
        put(fn("remember", "Foydalanuvchi ruxsat bergandan keyin muhim ma'lumotni uzoq muddatli xotiraga yozadi. Parol, karta raqami kabi maxfiy narsani yozma.",
            mapOf("text" to p("string", "Saqlanadigan qisqa fakt")), listOf("text")))
        put(fn("recall", "Xotiradan ma'lumot qidiradi.",
            mapOf("query" to p("string", "Kalit so'z; bo'sh bo'lsa oxirgi yozuvlar"))))
        put(fn("forget", "Foydalanuvchi so'raganda xotiradan mos yozuvlarni o'chiradi.",
            mapOf("query" to p("string", "O'chiriladigan yozuvdagi kalit so'z")), listOf("query")))
        put(fn("add_task", "Vazifa yoki eslatma qo'shadi. minutes_from_now berilsa, shu vaqtda bildirishnoma chiqadi.",
            mapOf(
                "title" to p("string", "Vazifa matni"),
                "minutes_from_now" to p("integer", "Necha daqiqadan keyin eslatilsin (ixtiyoriy)")
            ), listOf("title")))
        put(fn("list_tasks", "Bajarilmagan vazifalar ro'yxatini beradi."))
        put(fn("complete_task", "Vazifani bajarilgan deb belgilaydi.",
            mapOf("id" to p("integer", "Vazifa raqami")), listOf("id")))
        put(fn("open_app", "Telefondagi ilovani ochadi (ekranda tasdiq so'raladi).",
            mapOf("name" to p("string", "Ilova nomi")), listOf("name")))
        put(fn("set_alarm", "Budilnik o'rnatadi (tasdiq so'raladi).",
            mapOf(
                "hour" to p("integer", "Soat 0-23"),
                "minute" to p("integer", "Daqiqa 0-59"),
                "label" to p("string", "Izoh")
            ), listOf("hour", "minute")))
        put(fn("set_timer", "Taymer o'rnatadi (tasdiq so'raladi).",
            mapOf(
                "seconds" to p("integer", "Soniyalarda davomiylik"),
                "label" to p("string", "Izoh")
            ), listOf("seconds")))
        put(fn("find_contact", "Kontaktlardan ism bo'yicha qidiradi.",
            mapOf("name" to p("string", "Ism")), listOf("name")))
        put(fn("dial", "Qo'ng'iroq oynasini ochadi (raqam yoki kontakt ismi; tasdiq so'raladi).",
            mapOf("target" to p("string", "Telefon raqami yoki kontakt ismi")), listOf("target")))
        put(fn("music", "Faol musiqa ilovasini boshqaradi.",
            mapOf("action" to p("string", "play, pause, next yoki previous")), listOf("action")))
        put(fn("find_files", "Telefondagi (ruxsat berilgan) fayllarni nom bo'yicha qidiradi.",
            mapOf("query" to p("string", "Fayl nomidan bo'lak")), listOf("query")))
        put(fn("get_time", "Hozirgi sana va vaqtni beradi."))
        put(fn("who_is_here", "Kamera orqali yuzni tanish natijasini beradi: ega yoki begona odam."))
        put(fn("show_emotion", "Robot yuz ifodasini o'zgartiradi. Faqat his-tuyg'u keskin o'zgarganda ishlat.",
            mapOf("emotion" to p("string", "happy, surprised, serious, sad yoki neutral")), listOf("emotion")))
    }
}

class ToolExecutor(private val app: BekApp, private val search: WebSearch) {
    var onMood: ((String) -> Unit)? = null
    private val device = DeviceActions(app, app.confirm)

    suspend fun execute(name: String, a: JSONObject): ToolResult {
        return try {
            run(name, a)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ToolResult("Xato: ${e.message}")
        }
    }

    private suspend fun run(name: String, a: JSONObject): ToolResult = when (name) {
        "look" -> look(a.optString("camera"))
        "switch_camera" -> {
            if (!app.camera.running.value) ToolResult("Kamera o'chiq. Foydalanuvchidan KAMERA tugmasini bosishni so'ra.")
            else {
                withContext(Dispatchers.Main) { app.camera.switchCamera() }
                ToolResult(if (app.camera.isFront) "Old kamera yoqildi." else "Orqa kamera yoqildi.")
            }
        }
        "web_search" -> {
            val r = search.search(a.optString("query"), a.optBoolean("deep", false))
            ToolResult(r.text)
        }
        "remember" -> {
            val t = a.optString("text").trim()
            if (t.isEmpty()) ToolResult("Matn bo'sh.")
            else {
                app.db.memoryDao().insert(MemoryItem(text = t))
                ToolResult("Xotiraga yozildi.")
            }
        }
        "recall" -> {
            val q = a.optString("query").trim()
            val list = if (q.isEmpty()) app.db.memoryDao().list().take(15) else app.db.memoryDao().search(q)
            ToolResult(if (list.isEmpty()) "Xotirada mos yozuv yo'q." else list.joinToString("\n") { "- ${it.text}" })
        }
        "forget" -> {
            val n = app.db.memoryDao().deleteLike(a.optString("query").trim())
            ToolResult("$n ta yozuv o'chirildi.")
        }
        "add_task" -> addTask(a)
        "list_tasks" -> {
            val t = app.db.taskDao().open()
            ToolResult(if (t.isEmpty()) "Ochiq vazifa yo'q." else t.joinToString("\n") { "${it.id}. ${it.title}" })
        }
        "complete_task" -> {
            app.db.taskDao().setDone(a.optLong("id"), true)
            ToolResult("Vazifa bajarildi deb belgilandi.")
        }
        "open_app" -> ToolResult(device.openApp(a.optString("name")))
        "set_alarm" -> ToolResult(device.setAlarm(a.optInt("hour"), a.optInt("minute"), a.optString("label", "BEK")))
        "set_timer" -> ToolResult(device.setTimer(a.optInt("seconds"), a.optString("label", "BEK")))
        "find_contact" -> ToolResult(device.contactsText(a.optString("name")))
        "dial" -> ToolResult(device.dial(a.optString("target")))
        "music" -> ToolResult(device.music(a.optString("action")))
        "find_files" -> ToolResult(device.findFiles(a.optString("query")))
        "get_time" -> ToolResult(SimpleDateFormat("yyyy-MM-dd HH:mm, EEEE", Locale("uz")).format(Date()))
        "who_is_here" -> {
            val s = app.face.status.value
            ToolResult(if (!app.camera.running.value) "Kamera o'chiq." else s.text)
        }
        "show_emotion" -> {
            onMood?.invoke(a.optString("emotion"))
            ToolResult("ok")
        }
        else -> ToolResult("Noma'lum vosita: $name")
    }

    private suspend fun look(want: String): ToolResult {
        val hub = app.camera
        if (!hub.running.value) {
            return ToolResult("Kamera o'chiq. Foydalanuvchidan ekrandagi KAMERA tugmasini bosishni so'ra.")
        }
        if ((want == "front" && !hub.isFront) || (want == "back" && hub.isFront)) {
            withContext(Dispatchers.Main) { hub.switchCamera() }
        }
        var img: String? = null
        for (i in 0 until 20) {
            img = hub.jpegBase64()
            if (img != null) break
            delay(200)
        }
        return if (img == null) ToolResult("Kamera kadri hali tayyor emas, birozdan keyin qayta urinib ko'r.")
        else ToolResult("Kamera kadri yuborildi. Uni tahlil qilib, foydalanuvchi savoliga javob ber.", img)
    }

    private suspend fun addTask(a: JSONObject): ToolResult {
        val title = a.optString("title").trim()
        if (title.isEmpty()) return ToolResult("Vazifa matni bo'sh.")
        val mins = a.optInt("minutes_from_now", 0)
        val due = if (mins > 0) System.currentTimeMillis() + mins * 60_000L else null
        val id = app.db.taskDao().insert(TaskItem(title = title, dueAt = due))
        if (due != null) Reminders.schedule(app, id, title, due)
        return ToolResult(if (due != null) "Vazifa qo'shildi, $mins daqiqadan keyin eslatiladi." else "Vazifa qo'shildi.")
    }
}
