package uz.bek.robot.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import uz.bek.robot.data.Prefs
import java.util.concurrent.TimeUnit

data class SearchResult(val ok: Boolean, val text: String)

/** Internet qidiruvi: OpenAI Responses API + web_search vositasi. */
class WebSearch(private val prefs: Prefs) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .callTimeout(90, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String, deep: Boolean = false): SearchResult = withContext(Dispatchers.IO) {
        if (prefs.apiKey.isBlank()) return@withContext SearchResult(false, "API kalit kiritilmagan.")
        val how = if (deep) {
            "Bir nechta manbani ko'rib chiq, ma'lumotlarni solishtir, farqlarni va ishonchlilikni ayt."
        } else {
            "Eng ishonchli manbalardan aniq javob top."
        }
        val prompt = "Internetdan ma'lumot qidir va o'zbek tilida (lotin) qisqa, tahlilli xulosa yoz. " +
            "$how Faktlarni to'qima; topilmasa, shuni ayt. So'rov: $query"
        val body = JSONObject()
            .put("model", prefs.searchModel.trim())
            .put("tools", JSONArray().put(JSONObject().put("type", "web_search")))
            .put("input", prompt)
        val req = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .header("Authorization", "Bearer ${prefs.apiKey.trim()}")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        try {
            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    val m = try {
                        JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
                    } catch (_: Exception) {
                        ""
                    }
                    return@withContext SearchResult(false, "Qidiruv xatosi (${resp.code}): $m")
                }
                parse(raw)
            }
        } catch (e: Exception) {
            SearchResult(false, "Qidiruvda xato: ${e.message ?: "internet bilan muammo"}")
        }
    }

    private fun parse(raw: String): SearchResult {
        val j = JSONObject(raw)
        val out = j.optJSONArray("output") ?: JSONArray()
        val sb = StringBuilder()
        val sources = LinkedHashMap<String, String>()
        for (i in 0 until out.length()) {
            val item = out.getJSONObject(i)
            if (item.optString("type") != "message") continue
            val parts = item.optJSONArray("content") ?: continue
            for (k in 0 until parts.length()) {
                val c = parts.getJSONObject(k)
                if (c.optString("type") != "output_text") continue
                sb.append(c.optString("text"))
                val an = c.optJSONArray("annotations") ?: continue
                for (a in 0 until an.length()) {
                    val x = an.getJSONObject(a)
                    if (x.optString("type") == "url_citation") {
                        sources[x.optString("url")] = x.optString("title")
                    }
                }
            }
        }
        if (sb.isBlank()) return SearchResult(false, "Natija topilmadi.")
        if (sources.isNotEmpty()) {
            sb.append("\n\nManbalar:")
            sources.entries.take(6).forEach { sb.append("\n- ${it.value}: ${it.key}") }
        }
        return SearchResult(true, sb.toString().trim())
    }
}
