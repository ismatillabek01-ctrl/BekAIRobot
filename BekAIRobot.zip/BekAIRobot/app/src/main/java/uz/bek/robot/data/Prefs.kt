package uz.bek.robot.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Barcha sozlamalar va maxfiy ma'lumotlar (API kalit, yuz shabloni) shifrlangan holda saqlanadi. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "bek_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("bek_plain", Context.MODE_PRIVATE)
    }

    private fun str(key: String, def: String) = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = sp.getString(key, def) ?: def
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            sp.edit().putString(key, value).apply()
        }
    }

    private fun bool(key: String, def: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(key, value).apply()
        }
    }

    private fun flt(key: String, def: Float) = object : ReadWriteProperty<Any?, Float> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Float = sp.getFloat(key, def)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) {
            sp.edit().putFloat(key, value).apply()
        }
    }

    var apiKey by str("apiKey", "")
    var realtimeModel by str("realtimeModel", "gpt-realtime")
    var voice by str("voice", "marin")
    var searchModel by str("searchModel", "gpt-4.1-mini")
    var transcribeLang by str("transcribeLang", "")
    var ownerName by str("ownerName", "Ismatilla")
    var halfDuplex by bool("halfDuplex", true)
    var faceEnabled by bool("faceEnabled", false)
    var faceThreshold by flt("faceThreshold", 0.60f)
    var faceTemplate by str("faceTemplate", "")
}
