package uz.bek.robot.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import uz.bek.robot.BekApp
import uz.bek.robot.avatar.RobotFace

enum class Screen { HOME, MEMORY, TASKS, GAMES, HISTORY, SEARCH, SETTINGS, FACE }

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        (application as BekApp).camera.owner = this
        setContent { BekTheme { BekRoot(vm) } }
    }

    override fun onStop() {
        super.onStop()
        vm.onAppBackground()
    }

    override fun onDestroy() {
        (application as BekApp).camera.owner = null
        super.onDestroy()
    }
}

@Composable
fun BekRoot(vm: AppViewModel) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val app = LocalContext.current.applicationContext as BekApp
    val conn by vm.connection.collectAsState()
    val view = LocalView.current
    LaunchedEffect(conn) { view.keepScreenOn = conn != AppViewModel.Conn.IDLE }
    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    Box(Modifier.fillMaxSize().background(Ink)) {
        when (screen) {
            Screen.HOME -> HomeScreen(vm) { screen = it }
            Screen.MEMORY -> MemoryScreen { screen = Screen.HOME }
            Screen.TASKS -> TasksScreen { screen = Screen.HOME }
            Screen.GAMES -> GamesScreen(vm) { screen = it }
            Screen.HISTORY -> HistoryScreen { screen = Screen.HOME }
            Screen.SEARCH -> SearchScreen(vm) { screen = Screen.HOME }
            Screen.SETTINGS -> SettingsScreen(vm) { screen = Screen.HOME }
            Screen.FACE -> FaceScreen(vm) { screen = Screen.HOME }
        }
        ConfirmDialog(app)
    }
}

@Composable
fun ConfirmDialog(app: BekApp) {
    val req by app.confirm.pending.collectAsState()
    val r = req ?: return
    AlertDialog(
        onDismissRequest = { r.result.complete(false) },
        title = { Text("Tasdiqlang") },
        text = { Text(r.text) },
        confirmButton = { TextButton(onClick = { r.result.complete(true) }) { Text("Ruxsat") } },
        dismissButton = { TextButton(onClick = { r.result.complete(false) }) { Text("Rad etish") } }
    )
}

/** Ruxsat so'raydi; berilgan bo'lsa darhol, aks holda dialogdan keyin onGranted ni chaqiradi. */
@Composable
fun rememberAsk(permission: String, onGranted: () -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val cb by rememberUpdatedState(onGranted)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) cb()
    }
    return {
        if (ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED) cb()
        else launcher.launch(permission)
    }
}

@Composable
fun HomeScreen(vm: AppViewModel, onNav: (Screen) -> Unit) {
    val app = LocalContext.current.applicationContext as BekApp
    val conn by vm.connection.collectAsState()
    val st by vm.robotState.collectAsState()
    val mood by vm.mood.collectAsState()
    val mouth by vm.mouth.collectAsState()
    val user by vm.userCaption.collectAsState()
    val bot by vm.botCaption.collectAsState()
    val err by vm.error.collectAsState()
    val camOn by app.camera.running.collectAsState()
    val camErr by app.camera.error.collectAsState()
    val face by app.face.status.collectAsState()

    val askMic = rememberAsk(Manifest.permission.RECORD_AUDIO) { vm.startSession() }
    val askCam = rememberAsk(Manifest.permission.CAMERA) {
        app.camera.start()
        vm.applyFaceMode()
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Ink, Navy, Ink)))) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            StatusRow(conn, st, camOn)
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                RobotFace(mood, st, mouth, Modifier.fillMaxWidth().aspectRatio(1f))
            }
            if (camOn && face.text.isNotBlank() && app.face.mode != uz.bek.robot.camera.FaceController.Mode.OFF) {
                Text(face.text, color = Neon, fontSize = 12.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
            }
            err?.let {
                Text(it, color = Danger, fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
            }
            camErr?.let {
                Text(it, color = Danger, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
            if (user.isNotBlank()) {
                Text("Siz: $user", color = Muted, fontSize = 13.sp, maxLines = 2, textAlign = TextAlign.Center)
            }
            Text(
                bot.ifBlank { if (conn == AppViewModel.Conn.IDLE) "Salom! Men BEK. Gaplashish uchun mikrofon tugmasini bosing." else "" },
                color = Color.White, fontSize = 16.sp, maxLines = 4, textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 6.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                MicButton(conn) {
                    if (conn == AppViewModel.Conn.IDLE) askMic() else vm.stopSession()
                }
                if (st == uz.bek.robot.avatar.RobotState.SPEAKING) {
                    Text(
                        "✋ To'xtat", color = Neon,
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).clickable { vm.interrupt() }
                            .border(1.dp, Neon, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                NavChip("📷", "Kamera", camOn) {
                    if (camOn) {
                        app.camera.stop()
                        vm.applyFaceMode()
                    } else askCam()
                }
                NavChip("🔎", "Qidiruv") { onNav(Screen.SEARCH) }
                NavChip("🧠", "Xotira") { onNav(Screen.MEMORY) }
                NavChip("✅", "Vazifalar") { onNav(Screen.TASKS) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                NavChip("🎮", "O'yinlar") { onNav(Screen.GAMES) }
                NavChip("💬", "Tarix") { onNav(Screen.HISTORY) }
                NavChip("🙂", "Yuz") { onNav(Screen.FACE) }
                NavChip("⚙️", "Sozlama") { onNav(Screen.SETTINGS) }
            }
        }
        if (camOn) {
            CameraPip(app, Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(top = 44.dp, end = 12.dp))
        }
    }
}

@Composable
fun CameraPip(app: BekApp, modifier: Modifier = Modifier, big: Boolean = false) {
    DisposableEffect(Unit) { onDispose { app.camera.attachPreview(null) } }
    Box(
        modifier.then(
            if (big) Modifier.fillMaxWidth().aspectRatio(0.75f) else Modifier.width(110.dp).height(150.dp)
        ).clip(RoundedCornerShape(16.dp)).border(2.dp, Danger, RoundedCornerShape(16.dp))
    ) {
        AndroidView(
            factory = { c ->
                PreviewView(c).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                }
            },
            update = { pv -> app.camera.attachPreview(pv) },
            modifier = Modifier.fillMaxSize()
        )
        Text(
            "● KAMERA", color = Danger, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopStart).background(Color(0x99000000)).padding(4.dp)
        )
        Text(
            "🔄", fontSize = 18.sp,
            modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                .clip(CircleShape).background(Color(0x99000000)).clickable { app.camera.switchCamera() }.padding(6.dp)
        )
    }
}

@Composable
private fun StatusRow(conn: AppViewModel.Conn, st: uz.bek.robot.avatar.RobotState, camOn: Boolean) {
    val text = when {
        conn == AppViewModel.Conn.CONNECTING -> "Ulanmoqda…"
        conn == AppViewModel.Conn.IDLE -> "Tayyor"
        st == uz.bek.robot.avatar.RobotState.SPEAKING -> "Gapiryapman"
        st == uz.bek.robot.avatar.RobotState.THINKING -> "O'ylayapman…"
        else -> "Tinglayapman"
    }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("BEK", color = Neon, fontWeight = FontWeight.Black, fontSize = 22.sp)
        Spacer(Modifier.width(10.dp))
        Text(text, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.weight(1f))
        if (conn == AppViewModel.Conn.LIVE) Text("● MIKROFON", color = Danger, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        if (camOn) Text("   ● KAMERA", color = Danger, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MicButton(conn: AppViewModel.Conn, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "mic")
    val ring by inf.animateFloat(
        0.9f, 1.15f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "ring"
    )
    val live = conn != AppViewModel.Conn.IDLE
    Box(contentAlignment = Alignment.Center) {
        if (live) Box(Modifier.size((84 * ring).dp).border(2.dp, Neon.copy(alpha = 0.5f), CircleShape))
        Box(
            Modifier.size(76.dp).clip(CircleShape)
                .background(if (live) Danger else Neon)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Text(if (live) "⏹" else "🎙", fontSize = 30.sp)
        }
    }
}

@Composable
fun NavChip(emoji: String, label: String, active: Boolean = false, onClick: () -> Unit) {
    Column(
        Modifier.width(76.dp).clip(RoundedCornerShape(16.dp))
            .background(if (active) Neon.copy(alpha = 0.18f) else Panel)
            .border(BorderStroke(1.dp, if (active) Neon else Color(0xFF1B2B4D)), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 22.sp)
        Text(label, color = if (active) Neon else Color.White, fontSize = 11.sp)
    }
}
