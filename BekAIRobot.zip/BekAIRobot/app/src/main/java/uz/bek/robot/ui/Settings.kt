package uz.bek.robot.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.bek.robot.BekApp

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as BekApp
    val p = vm.prefs
    var key by remember { mutableStateOf(p.apiKey) }
    var model by remember { mutableStateOf(p.realtimeModel) }
    var voice by remember { mutableStateOf(p.voice) }
    var searchModel by remember { mutableStateOf(p.searchModel) }
    var lang by remember { mutableStateOf(p.transcribeLang) }
    var owner by remember { mutableStateOf(p.ownerName) }
    var half by remember { mutableStateOf(p.halfDuplex) }

    val askContacts = rememberAsk(Manifest.permission.READ_CONTACTS) {}
    val askNotif = rememberAsk(Manifest.permission.POST_NOTIFICATIONS) {}
    val askMedia = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    ScreenFrame("Sozlamalar", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text("OpenAI", color = Neon, fontSize = 14.sp)
            OutlinedTextField(
                key, { key = it; p.apiKey = it.trim() }, Modifier.fillMaxWidth(),
                label = { Text("API kalit") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Text(
                "Kalit APK ichida emas: u shu yerda kiritiladi va shifrlangan holda telefonda saqlanadi.",
                color = Muted, fontSize = 11.sp
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(model, { model = it; p.realtimeModel = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Realtime model") }, singleLine = true)
            OutlinedTextField(voice, { voice = it; p.voice = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Ovoz (masalan marin, cedar)") }, singleLine = true)
            OutlinedTextField(searchModel, { searchModel = it; p.searchModel = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Qidiruv modeli") }, singleLine = true)
            OutlinedTextField(
                lang, { lang = it; p.transcribeLang = it.trim() }, Modifier.fillMaxWidth(),
                label = { Text("Tanish tili kodi (ixtiyoriy, masalan uz)") }, singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            Text("Shaxsiy", color = Neon, fontSize = 14.sp)
            OutlinedTextField(owner, { owner = it; p.ownerName = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Ega ismi") }, singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(half, { half = it; p.halfDuplex = it })
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("Bek gapirganda mikrofon o'chiq", color = Color.White, fontSize = 13.sp)
                    Text("Dinamikdan chiqqan ovoz o'zini bezovta qilmasligi uchun (tavsiya). Kerak bo'lsa «To'xtat» tugmasi bor.", color = Muted, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Ruxsatlar", color = Neon, fontSize = 14.sp)
            OutlinedButton({ askContacts() }, Modifier.fillMaxWidth()) { Text("Kontaktlar") }
            OutlinedButton({ askNotif() }, Modifier.fillMaxWidth()) { Text("Bildirishnomalar (eslatmalar uchun)") }
            OutlinedButton({
                askMedia.launch(
                    arrayOf(
                        Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.READ_MEDIA_AUDIO
                    )
                )
            }, Modifier.fillMaxWidth()) { Text("Fayllarni qidirish (media)") }
            Spacer(Modifier.height(10.dp))
            Text("Diagnostika", color = Neon, fontSize = 14.sp)
            Text(app.camera.concurrentInfo(), color = Muted, fontSize = 12.sp)
            Text(
                if (app.face.modelAvailable) "Yuz modeli: yuklangan" else "Yuz modeli: yo'q (assets/mobilefacenet.tflite)",
                color = Muted, fontSize = 12.sp
            )
            Text("Versiya 1.0.0", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
        }
    }
}
