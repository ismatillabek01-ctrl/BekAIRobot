package uz.bek.robot.ai

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

const val SAMPLE_RATE = 24000

/** Mikrofondan 24 kHz mono PCM16 oqimini oladi (exo bekor qilish va shovqin pasaytirish bilan). */
class MicStreamer(private val onChunk: (ByteArray, Int) -> Unit) {
    private var rec: AudioRecord? = null
    private var job: Job? = null

    @SuppressLint("MissingPermission")
    fun start(scope: CoroutineScope) {
        stop()
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            max(minBuf, SAMPLE_RATE * 2 / 5)
        )
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            throw IllegalStateException("AudioRecord ishga tushmadi (mikrofon band yoki ruxsat yo'q)")
        }
        try {
            if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true
            if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.enabled = true
        } catch (_: Exception) {
        }
        r.startRecording()
        rec = r
        job = scope.launch(Dispatchers.IO) {
            val buf = ByteArray(SAMPLE_RATE * 2 / 10) // 100 ms
            while (isActive) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) onChunk(buf, n) else if (n < 0) break
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        try {
            rec?.stop()
        } catch (_: Exception) {
        }
        rec?.release()
        rec = null
    }
}

/** Robot ovozini ijro etadi va lab animatsiyasi uchun ovoz balandligini (level) beradi. */
class Speaker {
    private var track: AudioTrack? = null
    private val queue = Channel<ByteArray>(Channel.UNLIMITED)
    private var job: Job? = null
    private val queued = AtomicInteger(0)

    @Volatile
    private var busy = false

    @Volatile
    var level = 0f
        private set

    @Volatile
    private var lastWrite = 0L

    fun isSpeaking(): Boolean = queued.get() > 0 || busy || SystemClock.elapsedRealtime() < lastWrite + 350

    fun start(scope: CoroutineScope) {
        stop()
        val minBuf = AudioTrack.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuf, SAMPLE_RATE * 2 * 3 / 10))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.play()
        track = t
        job = scope.launch(Dispatchers.IO) {
            for (chunk in queue) {
                busy = true
                queued.decrementAndGet()
                var off = 0
                while (off < chunk.size && isActive) {
                    val n = min(960, chunk.size - off) // 20 ms
                    level = rms(chunk, off, n)
                    val w = t.write(chunk, off, n)
                    if (w < 0) break
                    off += n
                    lastWrite = SystemClock.elapsedRealtime()
                }
                busy = false
                if (queued.get() <= 0) level = 0f
            }
        }
    }

    fun enqueue(pcm: ByteArray) {
        queued.incrementAndGet()
        queue.trySend(pcm)
    }

    /** Gapirayotgan robotni darhol to'xtatadi. */
    fun flush() {
        while (queue.tryReceive().isSuccess) queued.decrementAndGet()
        if (queued.get() < 0) queued.set(0)
        level = 0f
        try {
            track?.pause()
            track?.flush()
            track?.play()
        } catch (_: Exception) {
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        while (queue.tryReceive().isSuccess) {
        }
        queued.set(0)
        busy = false
        level = 0f
        try {
            track?.stop()
        } catch (_: Exception) {
        }
        track?.release()
        track = null
    }

    private fun rms(b: ByteArray, off: Int, n: Int): Float {
        var sum = 0.0
        var cnt = 0
        var i = off
        while (i + 1 < off + n) {
            val s = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt()
            sum += s.toDouble() * s
            cnt++
            i += 2
        }
        if (cnt == 0) return 0f
        return min(1f, (sqrt(sum / cnt) / 32768.0 * 4.0).toFloat())
    }
}
