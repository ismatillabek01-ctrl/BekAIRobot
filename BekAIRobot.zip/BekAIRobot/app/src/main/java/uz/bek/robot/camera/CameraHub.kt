package uz.bek.robot.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.SystemClock
import android.util.Base64
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.max

/** Old/orqa kamerani boshqaradi, so'nggi kadrni saqlaydi va yuz tahlili uchun kadrlarni uzatadi. */
class CameraHub(private val app: Context) {
    var owner: LifecycleOwner? = null
    var frameCallback: ((Bitmap) -> Unit)? = null

    val running = MutableStateFlow(false)
    val lensFacing = MutableStateFlow(CameraSelector.LENS_FACING_FRONT)
    val error = MutableStateFlow<String?>(null)

    @Volatile
    private var last: Bitmap? = null
    private var preview: PreviewView? = null
    private val executor = Executors.newSingleThreadExecutor()

    @Volatile
    private var lastTs = 0L

    fun attachPreview(pv: PreviewView?) {
        if (preview === pv) return
        preview = pv
        if (running.value) bind()
    }

    fun start() {
        error.value = null
        running.value = true
        bind()
    }

    fun stop() {
        running.value = false
        last = null
        try {
            ProcessCameraProvider.getInstance(app).get().unbindAll()
        } catch (_: Exception) {
        }
    }

    fun switchCamera() {
        lensFacing.value =
            if (lensFacing.value == CameraSelector.LENS_FACING_FRONT) CameraSelector.LENS_FACING_BACK
            else CameraSelector.LENS_FACING_FRONT
        last = null
        if (running.value) bind()
    }

    val isFront: Boolean get() = lensFacing.value == CameraSelector.LENS_FACING_FRONT

    private fun bind() {
        val o = owner ?: return
        val future = ProcessCameraProvider.getInstance(app)
        future.addListener({
            try {
                val p = future.get()
                p.unbindAll()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing.value).build()
                if (!p.hasCamera(selector)) {
                    error.value = "Bu kamera topilmadi"
                    return@addListener
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { img -> analyze(img) }
                val cases = mutableListOf<UseCase>()
                preview?.let { pv ->
                    val pr = Preview.Builder().build()
                    pr.setSurfaceProvider(pv.surfaceProvider)
                    cases.add(pr)
                }
                cases.add(analysis)
                p.bindToLifecycle(o, selector, *cases.toTypedArray())
            } catch (e: Exception) {
                error.value = "Kamera xatosi: ${e.message}"
                running.value = false
            }
        }, ContextCompat.getMainExecutor(app))
    }

    private fun analyze(img: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastTs < 350) return
            lastTs = now
            val bmp = img.toBitmap()
            val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()) }
            var out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            val side = max(out.width, out.height)
            if (side > 768) {
                val k = 768f / side
                out = Bitmap.createScaledBitmap(out, (out.width * k).toInt(), (out.height * k).toInt(), true)
            }
            last = out
            frameCallback?.invoke(out)
        } catch (_: Exception) {
        } finally {
            img.close()
        }
    }

    /** So'nggi kadr JPEG/base64 ko'rinishida (AI ga yuborish uchun). */
    fun jpegBase64(): String? {
        val b = last ?: return null
        val bos = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 75, bos)
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    /** Old va orqa kamerani bir vaqtda ishlatish imkoniyati (Camera2 darajasida). */
    fun concurrentInfo(): String {
        if (Build.VERSION.SDK_INT < 30) return "Bir vaqtda ikki kamera: Android 11+ kerak"
        return try {
            val cm = app.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val sets = cm.concurrentCameraIds
            if (sets.isEmpty()) "Bir vaqtda ikki kamera: bu telefonda qo'llab-quvvatlanmaydi (kamera tez almashtiriladi)"
            else "Bir vaqtda ikki kamera: mumkin (${sets.size} kombinatsiya)"
        } catch (e: Exception) {
            "Kamera imkoniyatlarini aniqlab bo'lmadi: ${e.message}"
        }
    }
}
