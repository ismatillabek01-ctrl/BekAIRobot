package uz.bek.robot.ai

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import uz.bek.robot.data.Prefs
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * OpenAI Realtime API (WebSocket) mijozi.
 * Eslatma: listener metodlari OkHttp oqimida chaqiriladi.
 */
class RealtimeClient(private val prefs: Prefs, private val l: Listener) {

    interface Listener {
        fun onReady()
        fun onClosed(reason: String)
        fun onAudio(pcm: ByteArray)
        fun onUserText(text: String)
        fun onBotDelta(text: String)
        fun onBotDone(text: String)
        fun onSpeechStarted()
        fun onToolCall(callId: String, name: String, args: JSONObject)
        fun onError(msg: String)
    }

    private val http = OkHttpClient.Builder()
        .pingInterval(25, TimeUnit.SECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var ws: WebSocket? = null
    private val lock = Any()
    private var ready = false
    private var closedByUs = false
    private var responseActive = false
    private var wantResponse = false

    fun connect(instructions: String, tools: JSONArray) {
        val url = "wss://api.openai.com/v1/realtime?model=" +
            URLEncoder.encode(prefs.realtimeModel.trim(), "UTF-8")
        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer ${prefs.apiKey.trim()}")
            .build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                sendSessionUpdate(instructions, tools)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    handle(JSONObject(text))
                } catch (e: Exception) {
                    l.onError("Xabarni o'qishda xato: ${e.message}")
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!closedByUs) l.onClosed("Aloqa yopildi ($code)")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (closedByUs) return
                val msg = when (response?.code) {
                    401 -> "API kalit noto'g'ri yoki ruxsat yo'q (401)"
                    403 -> "Bu modelga ruxsat yo'q (403)"
                    404 -> "Model topilmadi (404). Sozlamalarda model nomini tekshiring"
                    429 -> "Limit yoki balans tugagan (429)"
                    else -> t.message ?: "Ulanish xatosi"
                }
                l.onClosed(msg)
            }
        })
    }

    private fun sendSessionUpdate(instructions: String, tools: JSONArray) {
        val input = JSONObject()
            .put("format", JSONObject().put("type", "audio/pcm").put("rate", SAMPLE_RATE))
            .put("turn_detection", JSONObject().put("type", "semantic_vad"))
        val transcription = JSONObject().put("model", "gpt-4o-transcribe")
        if (prefs.transcribeLang.isNotBlank()) transcription.put("language", prefs.transcribeLang.trim())
        input.put("transcription", transcription)

        val output = JSONObject()
            .put("format", JSONObject().put("type", "audio/pcm").put("rate", SAMPLE_RATE))
            .put("voice", prefs.voice.trim())

        val session = JSONObject()
            .put("type", "realtime")
            .put("model", prefs.realtimeModel.trim())
            .put("output_modalities", JSONArray().put("audio"))
            .put("instructions", instructions)
            .put("audio", JSONObject().put("input", input).put("output", output))
            .put("tools", tools)
            .put("tool_choice", "auto")
        send(JSONObject().put("type", "session.update").put("session", session))
    }

    private fun handle(e: JSONObject) {
        when (val type = e.optString("type")) {
            "session.updated" -> {
                if (!ready) {
                    ready = true
                    l.onReady()
                }
            }
            "response.created" -> synchronized(lock) { responseActive = true }
            "response.done" -> {
                val status = e.optJSONObject("response")?.optString("status").orEmpty()
                if (status == "failed") {
                    val m = e.optJSONObject("response")?.optJSONObject("status_details")
                        ?.optJSONObject("error")?.optString("message").orEmpty()
                    l.onError("Javob xatosi: $m")
                }
                var fire = false
                synchronized(lock) {
                    responseActive = false
                    if (wantResponse) {
                        wantResponse = false
                        fire = true
                    }
                }
                if (fire) send(JSONObject().put("type", "response.create"))
            }
            "response.output_audio.delta", "response.audio.delta" -> {
                val b64 = e.optString("delta")
                if (b64.isNotEmpty()) l.onAudio(Base64.decode(b64, Base64.DEFAULT))
            }
            "response.output_audio_transcript.delta", "response.audio_transcript.delta" ->
                l.onBotDelta(e.optString("delta"))
            "response.output_audio_transcript.done", "response.audio_transcript.done" ->
                l.onBotDone(e.optString("transcript"))
            "conversation.item.input_audio_transcription.completed" -> {
                val t = e.optString("transcript").trim()
                if (t.isNotEmpty()) l.onUserText(t)
            }
            "input_audio_buffer.speech_started" -> l.onSpeechStarted()
            "response.function_call_arguments.done" -> {
                val argsStr = e.optString("arguments")
                val args = try {
                    if (argsStr.isBlank()) JSONObject() else JSONObject(argsStr)
                } catch (_: Exception) {
                    JSONObject()
                }
                l.onToolCall(e.optString("call_id"), e.optString("name"), args)
            }
            "error" -> {
                val err = e.optJSONObject("error")
                val code = err?.optString("code").orEmpty()
                val msg = err?.optString("message").orEmpty()
                if (code.contains("cancel_not_active")) return
                l.onError(if (msg.isBlank()) "Noma'lum xato ($type)" else msg)
            }
        }
    }

    private fun send(o: JSONObject): Boolean = ws?.send(o.toString()) ?: false

    fun sendAudio(buf: ByteArray, len: Int) {
        if (!ready) return
        val b64 = Base64.encodeToString(buf, 0, len, Base64.NO_WRAP)
        send(JSONObject().put("type", "input_audio_buffer.append").put("audio", b64))
    }

    private fun requestResponse() {
        var fireNow = false
        synchronized(lock) {
            if (responseActive) wantResponse = true else fireNow = true
        }
        if (fireNow) send(JSONObject().put("type", "response.create"))
    }

    private fun addMessage(role: String, content: JSONArray) {
        send(
            JSONObject().put("type", "conversation.item.create").put(
                "item", JSONObject().put("type", "message").put("role", role).put("content", content)
            )
        )
    }

    /** Foydalanuvchi nomidan matn yuboradi va javob so'raydi. */
    fun sendUserText(text: String) {
        addMessage("user", JSONArray().put(JSONObject().put("type", "input_text").put("text", text)))
        requestResponse()
    }

    /** Tizim eslatmasi (javob talab qilmaydi). */
    fun sendSystemNote(text: String) {
        addMessage("system", JSONArray().put(JSONObject().put("type", "input_text").put("text", text)))
    }

    fun submitToolResult(callId: String, output: String, imageB64: String?, last: Boolean) {
        send(
            JSONObject().put("type", "conversation.item.create").put(
                "item", JSONObject().put("type", "function_call_output")
                    .put("call_id", callId).put("output", output)
            )
        )
        if (imageB64 != null) {
            addMessage(
                "user", JSONArray()
                    .put(JSONObject().put("type", "input_text").put("text", "(Kamera kadri)"))
                    .put(JSONObject().put("type", "input_image").put("image_url", "data:image/jpeg;base64,$imageB64"))
            )
        }
        if (last) requestResponse()
    }

    fun cancelResponse() {
        send(JSONObject().put("type", "response.cancel"))
    }

    fun close() {
        closedByUs = true
        try {
            ws?.close(1000, "bye")
        } catch (_: Exception) {
        }
        ws = null
    }
}
