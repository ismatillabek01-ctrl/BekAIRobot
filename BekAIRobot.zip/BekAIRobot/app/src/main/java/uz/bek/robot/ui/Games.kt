package uz.bek.robot.ui

import android.Manifest
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val voiceGames = listOf(
    "♟ Shaxmat" to "Keling, shaxmat o'ynaymiz. Men oq donalar bilan boshlayman. Yurishlarni algebraik yozuvda aytaman (masalan e2-e4); har yurishdan keyin o'z yurishingizni ayting va doskani eslab boring.",
    "❓ Viktorina" to "Keling, viktorina o'ynaymiz. Menga birma-bir 5 ta qiziqarli savol bering va har javobdan keyin ballni hisoblab boring.",
    "🧩 Topishmoqlar" to "Menga bitta-bitta topishmoq ayting, javobni men topay; topolmasam, ishora bering.",
    "🧠 Mantiqiy savollar" to "Menga bitta-bitta mantiqiy savol bering va yechimim ustida birga fikrlaymiz.",
    "🔤 So'z o'yini" to "Keling, so'z o'yini o'ynaymiz: oldingi so'zning oxirgi harfidan boshlanadigan so'z aytamiz. Siz boshlang.",
    "➗ Matematik o'yin" to "Menga tezkor matematik misollar bering, birma-bir, qiyinligini asta oshiring.",
    "🔢 Xotira mashqi" to "Menga raqamlar yoki so'zlar ketma-ketligini ayting, men takrorlayman; har safar uzunroq qiling."
)

@Composable
fun GamesScreen(vm: AppViewModel, onNav: (Screen) -> Unit) {
    var pending by remember { mutableStateOf<String?>(null) }
    val askMic = rememberAsk(Manifest.permission.RECORD_AUDIO) {
        pending?.let {
            vm.startSession(it)
            onNav(Screen.HOME)
        }
        pending = null
    }
    var offline by remember { mutableStateOf("") }

    ScreenFrame("O'yinlar", { if (offline.isNotEmpty()) offline = "" else onNav(Screen.HOME) }) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            when (offline) {
                "math" -> MathGame()
                "riddle" -> RiddleGame()
                "memory" -> DigitMemoryGame()
                else -> {
                    Text("Bek bilan (internet kerak)", color = Neon, fontSize = 14.sp)
                    voiceGames.forEach { (label, opening) ->
                        OutlinedButton(
                            onClick = {
                                pending = opening
                                askMic()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(label) }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Oflayn o'yinlar (internetsiz ishlaydi)", color = Neon, fontSize = 14.sp)
                    Button({ offline = "math" }, Modifier.fillMaxWidth()) { Text("➗ Tezkor hisob") }
                    Button({ offline = "riddle" }, Modifier.fillMaxWidth()) { Text("🧩 Topishmoqlar") }
                    Button({ offline = "memory" }, Modifier.fillMaxWidth()) { Text("🔢 Raqamlar xotirasi") }
                }
            }
        }
    }
}

@Composable
private fun MathGame() {
    var score by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }
    var a by remember { mutableIntStateOf(Random.nextInt(2, 20)) }
    var b by remember { mutableIntStateOf(Random.nextInt(2, 20)) }
    var op by remember { mutableIntStateOf(Random.nextInt(3)) }
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    fun answer() = when (op) {
        0 -> a + b
        1 -> a - b
        else -> a * b
    }

    val sign = listOf("+", "−", "×")[op]
    Text("Tezkor hisob  •  To'g'ri: $score / $total", color = Muted)
    Spacer(Modifier.height(10.dp))
    Text("$a $sign $b = ?", color = Color.White, fontSize = 34.sp)
    OutlinedTextField(
        input, { input = it.filter { c -> c.isDigit() || c == '-' }.take(6) },
        Modifier.fillMaxWidth(), singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
    Spacer(Modifier.height(6.dp))
    Button(onClick = {
        val v = input.toIntOrNull()
        if (v != null) {
            total++
            if (v == answer()) {
                score++
                msg = "To'g'ri! ✅"
            } else {
                msg = "Xato. Javob: ${answer()}"
            }
            a = Random.nextInt(2, 20 + score)
            b = Random.nextInt(2, 20 + score)
            op = Random.nextInt(3)
            input = ""
        }
    }, Modifier.fillMaxWidth()) { Text("Tekshirish") }
    Text(msg, color = Color.White)
}

private val riddles = listOf(
    "Nimani qancha ko'p olsang, u shuncha kattalashadi?" to "Chuqur",
    "Ikki qo'li bor, lekin hech narsani ushlamaydi; to'xtamay yuradi. U nima?" to "Soat",
    "Hamma narsani aks ettiradi, lekin o'zi gapirmaydi. U nima?" to "Ko'zgu",
    "Sizniki, lekin boshqalar undan ko'proq foydalanadi. U nima?" to "Ismingiz",
    "Qishda ham, yozda ham yashil; bargi ignaga o'xshaydi. U nima?" to "Archa"
)

@Composable
private fun RiddleGame() {
    var i by remember { mutableIntStateOf(Random.nextInt(riddles.size)) }
    var show by remember { mutableStateOf(false) }
    Text("Topishmoq", color = Muted)
    Spacer(Modifier.height(8.dp))
    Text(riddles[i].first, color = Color.White, fontSize = 20.sp)
    Spacer(Modifier.height(10.dp))
    if (show) Text("Javob: ${riddles[i].second}", color = Neon, fontSize = 20.sp)
    Spacer(Modifier.height(10.dp))
    Row {
        OutlinedButton({ show = true }) { Text("Javobni ko'rish") }
        Spacer(Modifier.width(8.dp))
        Button({
            i = (i + 1 + Random.nextInt(riddles.size - 1)) % riddles.size
            show = false
        }) { Text("Keyingisi") }
    }
}

@Composable
private fun DigitMemoryGame() {
    var level by remember { mutableIntStateOf(3) }
    var seq by remember { mutableStateOf(newSeq(3)) }
    var phase by remember { mutableIntStateOf(0) } // 0 ko'rsatish, 1 kiritish, 2 natija
    var input by remember { mutableStateOf("") }
    var ok by remember { mutableStateOf(false) }

    LaunchedEffect(seq, phase) {
        if (phase == 0) {
            delay(1200L + level * 450L)
            phase = 1
        }
    }
    Text("Raqamlar xotirasi  •  Daraja: $level", color = Muted)
    Spacer(Modifier.height(10.dp))
    when (phase) {
        0 -> Text(seq, color = Neon, fontSize = 40.sp)
        1 -> {
            Text("Eslagan raqamlaringizni kiriting", color = Color.White)
            OutlinedTextField(
                input, { input = it.filter { c -> c.isDigit() }.take(level) },
                Modifier.fillMaxWidth(), singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Button({
                ok = input == seq
                phase = 2
            }, Modifier.fillMaxWidth()) { Text("Tekshirish") }
        }
        else -> {
            Text(if (ok) "To'g'ri! ✅" else "Xato. Bu edi: $seq", color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Button({
                level = if (ok) level + 1 else 3
                seq = newSeq(level)
                input = ""
                phase = 0
            }, Modifier.fillMaxWidth()) { Text(if (ok) "Keyingi daraja" else "Qaytadan") }
        }
    }
}

private fun newSeq(n: Int): String = buildString { repeat(n) { append(Random.nextInt(10)) } }
