package uz.bek.robot.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Neon = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)
val Ink = Color(0xFF05070D)
val Navy = Color(0xFF0A1630)
val Panel = Color(0xFF0E1A33)
val Muted = Color(0xFF8FA3C4)
val Danger = Color(0xFFFF4D4D)

@Composable
fun BekTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon,
            onPrimary = Ink,
            secondary = Blue,
            background = Ink,
            surface = Panel,
            onSurface = Color.White,
            onBackground = Color.White,
            surfaceVariant = Navy,
            error = Danger
        ),
        content = content
    )
}
