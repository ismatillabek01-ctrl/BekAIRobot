package uz.bek.robot.ui

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import uz.bek.robot.BekApp
import uz.bek.robot.camera.FaceController
import uz.bek.robot.data.MemoryItem
import uz.bek.robot.data.TaskItem
import uz.bek.robot.device.Reminders
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ScreenFrame(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Ink).systemBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "←", color = Neon, fontSize = 26.sp,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onBack).padding(horizontal = 10.dp, vertical = 2.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun rowCard(content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) { content() }
}

private val dateFmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

// ---------------- XOTIRA ----------------

@Composable
fun MemoryScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as BekApp
    val scope = rememberCoroutineScope()
    val flow = remember { app.db.memoryDao().all() }
    val items by flow.collectAsState(initial = emptyList())
    var text by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }

    ScreenFrame("Xotira", onBack) {
        Text("Bek siz ruxsat bergan ma'lumotlarni shu yerda saqlaydi. Istalgan yozuvni o'chirishingiz mumkin.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Yangi yozuv") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (text.isNotBlank()) {
                    val t = text.trim()
                    scope.launch { app.db.memoryDao().insert(MemoryItem(text = t)) }
                    text = ""
                }
            }) { Text("+") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(items, key = { it.id }) { m ->
                rowCard {
                    Column(Modifier.weight(1f)) {
                        Text(m.text, color = Color.White)
                        Text(dateFmt.format(Date(m.createdAt)), color = Muted, fontSize = 11.sp)
                    }
                    Text("✕", color = Danger, fontSize = 18.sp,
                        modifier = Modifier.clickable { scope.launch { app.db.memoryDao().delete(m.id) } }.padding(8.dp))
                }
            }
        }
        if (items.isNotEmpty()) {
            TextButton(onClick = { confirmClear = true }) { Text("Hammasini o'chirish", color = Danger) }
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Xotirani tozalash") },
            text = { Text("Barcha yozuvlar o'chiriladi. Davom etasizmi?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { app.db.memoryDao().clear() }
                    confirmClear = false
                }) { Text("O'chirish", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Bekor") } }
        )
    }
}

// ---------------- VAZIFALAR ----------------

@Composable
fun TasksScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as BekApp
    val scope = rememberCoroutineScope()
    val flow = remember { app.db.taskDao().all() }
    val items by flow.collectAsState(initial = emptyList())
    var text by remember { mutableStateOf("") }
    var mins by remember { mutableStateOf("") }
    val askNotif = rememberAsk(Manifest.permission.POST_NOTIFICATIONS) {}

    ScreenFrame("Vazifalar", onBack) {
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), placeholder = { Text("Yangi vazifa") })
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                mins, { s -> mins = s.filter { it.isDigit() }.take(5) }, Modifier.weight(1f),
                placeholder = { Text("Necha daqiqadan keyin eslatilsin (ixtiyoriy)") }, singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                val t = text.trim()
                if (t.isNotEmpty()) {
                    val m = mins.toIntOrNull() ?: 0
                    val due = if (m > 0) System.currentTimeMillis() + m * 60_000L else null
                    if (due != null) askNotif()
                    scope.launch {
                        val id = app.db.taskDao().insert(TaskItem(title = t, dueAt = due))
                        if (due != null) Reminders.schedule(app, id, t, due)
                    }
                    text = ""
                    mins = ""
                }
            }) { Text("+") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(items, key = { it.id }) { t ->
                rowCard {
                    Checkbox(t.done, { scope.launch { app.db.taskDao().setDone(t.id, it) } })
                    Column(Modifier.weight(1f)) {
                        Text(
                            t.title, color = if (t.done) Muted else Color.White,
                            textDecoration = if (t.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                        )
                        t.dueAt?.let { Text("Eslatma: ${dateFmt.format(Date(it))}", color = Muted, fontSize = 11.sp) }
                    }
                    Text("✕", color = Danger, fontSize = 18.sp,
                        modifier = Modifier.clickable { scope.launch { app.db.taskDao().delete(t.id) } }.padding(8.dp))
                }
            }
        }
    }
}

// ---------------- TARIX ----------------

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as BekApp
    val scope = rememberCoroutineScope()
    val flow = remember { app.db.messageDao().recent() }
    val items by flow.collectAsState(initial = emptyList())
    var confirm by remember { mutableStateOf(false) }

    ScreenFrame("Suhbat tarixi", onBack) {
        if (items.isEmpty()) Text("Hozircha suhbat yo'q.", color = Muted)
        LazyColumn(Modifier.weight(1f)) {
            items(items, key = { it.id }) { m ->
                val mine = m.role == "user"
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                    Text(
                        m.text, color = if (mine) Ink else Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(14.dp))
                            .background(if (mine) Neon else Panel).padding(10.dp)
                    )
                    Text(dateFmt.format(Date(m.ts)), color = Muted, fontSize = 10.sp)
                }
            }
        }
        if (items.isNotEmpty()) TextButton(onClick = { confirm = true }) { Text("Tarixni tozalash", color = Danger) }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Tarixni tozalash") },
            text = { Text("Barcha suhbatlar o'chiriladi. Davom etasizmi?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { app.db.messageDao().clear() }
                    confirm = false
                }) { Text("O'chirish", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Bekor") } }
        )
    }
}

// ---------------- QIDIRUV ----------------

@Composable
fun SearchScreen(vm: AppViewModel, onBack: () -> Unit) {
    val state by vm.searchState.collectAsState()
    var q by remember { mutableStateOf("") }
    var deep by remember { mutableStateOf(false) }
    ScreenFrame("Internet qidiruv", onBack) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Nimani izlaymiz?") })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(deep, { deep = it })
            Spacer(Modifier.width(8.dp))
            Text("Chuqur qidiruv (ko'p manba, solishtirish)", color = Muted, fontSize = 12.sp)
        }
        Button(onClick = { vm.runSearch(q, deep) }, Modifier.fillMaxWidth()) { Text("Qidirish") }
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            when (val s = state) {
                is SearchUi.Idle -> Text("Natija shu yerda ko'rinadi.", color = Muted)
                is SearchUi.Loading -> Text("Qidirilmoqda…", color = Neon)
                is SearchUi.Done -> Text(s.text, color = Color.White)
                is SearchUi.Fail -> Text(s.text, color = Danger)
            }
        }
    }
}

// ---------------- YUZ ----------------

@Composable
fun FaceScreen(vm: AppViewModel, onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as BekApp
    val camOn by app.camera.running.collectAsState()
    val status by app.face.status.collectAsState()
    var enabled by remember { mutableStateOf(vm.prefs.faceEnabled) }
    var thr by remember { mutableStateOf(vm.prefs.faceThreshold) }
    val askCam = rememberAsk(Manifest.permission.CAMERA) {
        if (!app.camera.isFront) app.camera.switchCamera()
        app.camera.start()
    }
    DisposableEffect(Unit) {
        onDispose {
            app.face.mode = FaceController.Mode.OFF
            app.camera.stop()
            vm.applyFaceMode()
        }
    }

    ScreenFrame("Yuzni tanish", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            if (!app.face.modelAvailable) {
                Text(
                    "Yuz modeli topilmadi: app/src/main/assets/mobilefacenet.tflite faylini qo'shing (qo'llanmaga qarang). " +
                        "Model bo'lmasa faqat odam soni va ko'z pirpirashi aniqlanadi.",
                    color = Danger, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
            }
            if (camOn) {
                CameraPip(app, Modifier.fillMaxWidth(), big = true)
            } else {
                Button(onClick = { askCam() }, Modifier.fillMaxWidth()) { Text("Kamerani yoqish") }
            }
            Spacer(Modifier.height(8.dp))
            Text(status.text, color = Neon)
            if (status.progress > 0f && status.progress < 1f) {
                androidx.compose.material3.LinearProgressIndicator(progress = { status.progress }, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { if (camOn) app.face.startEnroll() },
                enabled = camOn, modifier = Modifier.fillMaxWidth()
            ) { Text("Yuzimni ro'yxatdan o'tkazish") }
            OutlinedButton(
                onClick = {
                    app.face.mode = FaceController.Mode.RECOGNIZE
                },
                enabled = camOn && vm.prefs.faceTemplate.isNotBlank(), modifier = Modifier.fillMaxWidth()
            ) { Text("Tekshirib ko'rish") }
            OutlinedButton(
                onClick = { app.face.clearTemplate() },
                enabled = vm.prefs.faceTemplate.isNotBlank(), modifier = Modifier.fillMaxWidth()
            ) { Text("Yuz ma'lumotini o'chirish", color = Danger) }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(enabled, { enabled = it; vm.prefs.faceEnabled = it })
                Spacer(Modifier.width(8.dp))
                Text("Bosh ekranda kamera yoqilganda egani tanish", color = Color.White, fontSize = 13.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text("Moslik chegarasi: ${(thr * 100).toInt()}%", color = Muted, fontSize = 12.sp)
            androidx.compose.material3.Slider(
                value = thr, onValueChange = { thr = it; vm.prefs.faceThreshold = it },
                valueRange = 0.3f..0.9f
            )
            Text(
                "Yuz shabloni faqat shu telefonda, shifrlangan holda saqlanadi. Jonlilik tekshiruvi ko'z pirpirashiga asoslangan: " +
                    "bu oddiy fotosurat bilan aldashdan himoya qiladi, lekin video yoki 3D niqobga qarshi kafolat emas. " +
                    "Yuz orqali tanish muhim amallarda (to'lov, parol) yagona himoya sifatida ishlatilmasin.",
                color = Muted, fontSize = 11.sp
            )
        }
    }
}
