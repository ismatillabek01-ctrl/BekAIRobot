Bu yerga mobilefacenet.tflite faylini qo'ying (README ga qarang).
