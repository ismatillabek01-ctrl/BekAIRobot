# BEK AI ROBOT

Android telefonda ishlaydigan shaxsiy AI hamroh: jonli robot yuzi, o'zbekcha ovozli suhbat (OpenAI Realtime API), kamera orqali ko'rish, yuzni tanish, xotira, internet qidiruv, vazifalar, telefon boshqaruvi va o'yinlar.

> Holat: kod to'liq yozilgan, lekin **hali kompilyatsiya qilinmagan va telefonda sinalmagan** (yaratilgan muhitda Android SDK yo'q edi). Birinchi yig'ishda mayda xatolar chiqishi mumkin; xato matnini yuborsangiz, tuzatiladi.

## APK ni olishning 2 yo'li

### A) Android Studio (Windows)
1. Android Studio (Koala yoki yangiroq) o'rnating.
2. **File → Open** → `BekAIRobot` papkasini tanlang. Gradle sinxronlanishini kuting (birinchi marta 5-15 daqiqa, internet kerak).
3. Telefonda: **Sozlamalar → Telefon haqida → MIUI versiyasi** ga 7 marta bosing, so'ng **Qo'shimcha sozlamalar → Dasturchilar uchun → USB orqali nosozliklarni tuzatish** ni yoqing.
4. Telefonni USB bilan ulang va **Run ▶** bosing, yoki APK uchun: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Tayyor fayl: `app\build\outputs\apk\debug\app-debug.apk`. Uni telefonga ko'chirib o'rnating.

### B) GitHub Actions (Android Studio'siz)
1. GitHub'da yangi (private) repozitoriy oching va shu papkadagi hamma narsani yuklang.
2. **Actions → Build APK → Run workflow**.
3. Tugagach, **Artifacts → BekAIRobot-debug-apk** dan `app-debug.apk` ni yuklab oling.

## Birinchi ishga tushirish
1. Ilovani oching → **⚙️ Sozlama** → **API kalit** maydoniga OpenAI kalitingizni kiriting (kalit kodda emas, telefonda shifrlangan holda saqlanadi).
2. Bosh ekranda 🎙 tugmasini bosing, mikrofon ruxsatini bering va gapiring.
3. Boshqa funksiyalar uchun Sozlamalardagi **Ruxsatlar** bo'limidan ruxsat bering (kontaktlar, bildirishnoma, fayllar).

## Yuzni tanish uchun model (ixtiyoriy)
Yuzni shaxs sifatida tanish uchun MobileFaceNet turidagi TFLite embedding modeli kerak (kirish 112×112×3, chiqish 128 yoki 192 o'lchamli vektor). Uni `app/src/main/assets/mobilefacenet.tflite` nomi bilan qo'ying va qayta yig'ing. Model bo'lmasa, ilova baribir ishlaydi: faqat kadrdagi odam soni va ko'z pirpirashi aniqlanadi. Moslik chegarasini (standart 60%) **Yuz** ekranida o'zingizning yuzingizga qarab sozlang.

## Bilish kerak bo'lgan cheklovlar
- **Model nomi**: standart `gpt-realtime`. Hisobingizda boshqa nom bo'lsa, Sozlamalarda o'zgartiring.
- **Ovoz sifati**: o'zbek tilidagi tanish va talaffuz sifatini telefonda sinab ko'ring. Tanish tili kodini (`uz`) Sozlamalarda berish mumkin; xato chiqsa, bo'sh qoldiring.
- **Ikki kamera bir vaqtda**: Redmi Note 13R Pro'da ishlashi kafolatlanmagan. Sozlamalar → Diagnostika natijani ko'rsatadi; kameralar tez almashtiriladi.
- **Fon rejimi yo'q**: ilova fonga o'tsa, mikrofon va kamera o'chadi (Android cheklovi va maxfiylik uchun). Yashirin kuzatuv yo'q.
- **API kalit**: bu shaxsiy foydalanish uchun. Ilovani boshqalarga tarqatsangiz, kalit o'rniga server orqali vaqtinchalik token berish kerak.
- **Tasdiq**: ilova ochish, qo'ng'iroq oynasi, budilnik va taymer ekranda sizning tasdig'ingizni so'raydi.
- **Debug APK**: o'rnatish uchun tayyor, lekin Play Market uchun emas (release imzo kerak).
- **Xarajat**: Realtime API va qidiruv pullik. Foydalanishni OpenAI hisobingizda kuzatib boring.

## Tuzilma
Batafsil: `docs/TEXNIK_HUJJAT.md`
