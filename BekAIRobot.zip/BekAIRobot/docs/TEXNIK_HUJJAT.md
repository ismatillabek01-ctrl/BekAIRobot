# BEK AI ROBOT: texnik hujjat

## Texnologiyalar
Kotlin 1.9.24, Jetpack Compose (Material 3), CameraX 1.3.4, ML Kit Face Detection, TensorFlow Lite, Room 2.6.1, OkHttp (WebSocket), EncryptedSharedPreferences. minSdk 26, targetSdk 34.

## Modullar (`app/src/main/java/uz/bek/robot`)
| Paket / fayl | Vazifasi |
|---|---|
| `ai/RealtimeClient.kt` | OpenAI Realtime WebSocket: sessiya sozlash, audio oqimi, transkript, vosita chaqiruvlari, rasm yuborish |
| `ai/AudioIO.kt` | Mikrofon (24 kHz PCM16, exo bekor qilish) va dinamik (lab animatsiyasi uchun ovoz balandligi) |
| `ai/Tools.kt` | 19 ta vosita ta'rifi va bajaruvchi: kamera, qidiruv, xotira, vazifa, telefon amallari |
| `ai/WebSearch.kt` | Responses API + web_search orqali internet qidiruv va manbalar |
| `avatar/RobotFace.kt` | Canvas'da chizilgan jonli robot: ko'z pirpirashi, lab, bosh, 5 kayfiyat, 4 holat |
| `camera/CameraHub.kt` | Old/orqa kamera, so'nggi kadr, Camera2 bir vaqtda ikki kamera tekshiruvi |
| `camera/Face.kt` | Yuzni aniqlash, embedding, ro'yxatdan o'tkazish, ko'z pirpirashi orqali jonlilik |
| `device/Device.kt` | Ilova ochish, budilnik, taymer, kontakt, qo'ng'iroq oynasi, musiqa, fayl qidirish, eslatma, tasdiq dialogi |
| `data/` | Room (xotira, vazifalar, tarix) va shifrlangan sozlamalar |
| `ui/` | Ekranlar: bosh, xotira, vazifalar, tarix, qidiruv, yuz, o'yinlar, sozlamalar |

## Suhbat oqimi
Mikrofon → `input_audio_buffer.append` → server VAD → javob audiosi (`response.output_audio.delta`) → `Speaker` → dinamik. Vosita chaqirilsa (`response.function_call_arguments.done`), `ToolExecutor` bajaradi, natija `function_call_output` sifatida yuboriladi va `response.done` dan keyin `response.create` jo'natiladi. Kamera kadri `input_image` sifatida suhbatga qo'shiladi.

## Xavfsizlik va maxfiylik
- API kalit APK ichida yo'q; shifrlangan xotirada (Android Keystore, AES-256).
- Yuz shabloni faqat qurilmada, shifrlangan holda.
- Mikrofon/kamera faqat ilova ekranda ochiq paytda ishlaydi, ekranda qizil ko'rsatkich bor; fonga o'tganda avtomatik o'chadi.
- Telefon amallari ekranda tasdiq talab qiladi; `allowBackup=false`.
- Xotiraga yozishdan oldin Bek ruxsat so'raydi (ko'rsatma orqali); xotirani ko'rish, o'chirish ekranda bor.
- Begona odam aniqlansa, Bek egaga tegishli xotirani aytmasligi tizim ko'rsatmasida belgilangan (modelga bog'liq, 100% kafolat emas).

## Oflayn rejim
Internet bo'lmasa: xotira, vazifalar, eslatmalar, tarix va 3 ta oflayn o'yin ishlaydi. AI funksiyalari uchun aniq xabar chiqadi.

## Keyinchalik yaxshilash mumkin
- 3D robot (Filament/Rive), aniq viseme asosidagi lab sinxronizatsiyasi.
- Server orqali vaqtinchalik Realtime token (tarqatish uchun).
- Fonda ishlash uchun foreground service (Android 14 talablariga ko'ra, ko'rsatkich bilan).
- Chuqurroq jonlilik tekshiruvi (bosh burilishi, IR/chuqurlik).
